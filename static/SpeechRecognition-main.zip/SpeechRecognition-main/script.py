import nltk
nltk.download('punkt')
print("NLTK is installed successfully!")